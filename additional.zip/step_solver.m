function [x_axis, output_V, I_new] = step_solver(C_noise, G_noise, step_count)
%Step_Solver takes the C, G, #iterations as input
%   Outputs a vector to be plotted for x-axis, the output voltage, and
%   current noise levels


dt = 1/step_count;                      % change dt based on current step size
x_axis = linspace(0,1,step_count);      % x values to be plotted from 0s to 1s
input_V = gaussmf(x_axis, [0.03 0.06]); % input function = gaussian for these x-values
output_V = zeros(8,step_count);         % create output vector
F_value = zeros(8,1);                   % F vector

I_new = 0.001*randn(1, step_count);     % define thermal noise

for k = 1:1:step_count-1
    if k > 1
        F_value(1,1) = input_V(1,k);
        F_value(3,1) = I_new(1,k);
        output_V(:, k+1) = (C_noise/dt + G_noise) \ (C_noise*output_V(:,k)/dt + F_value);
    else % k = 1
        F_value(1,1) = input_V(1,1);
        output_V(:, k) = (C_noise/dt + G_noise) \ (C_noise*output_V(:,1)/dt + F_value);
    end
end
end

