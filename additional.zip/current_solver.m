function [Curr, Vmap, Ex, Ey, eFlowx, eFlowy, Cnx] = current_solver(stepped_voltage)
%current_solver 
% Inputs: stepped_voltage = the present voltage value that goes from 0.1 to
% 10V (assignment 4 specs)
% Outputs: Cnx = average Current for that Voltage value
%          Curr, Vmap, Ex, Ey, eFlowx, eFlowy


Len = 200e-9;
Wid = 100e-9;
ny = 200;
nx = 100;

G = sparse(ny*nx, ny*nx);
V = zeros(nx*ny,1);
boundary_condition = [1 1 0 0];
part = 3;

cMap = zeros(nx, ny);
boxL = round(0.4*nx);
boxR = round(0.6*nx);
boxT = round(0.6*ny);
boxB = round(0.4*ny);

for i = 1:nx
    for j = 1:ny
        cMap(i,j) = 1; % outside the box
            if ((i>=boxL && i<=boxR && j>=boxT) || (i>=boxL && i<=boxR && j<=boxB )) 
                cMap(i,j) = 0.01; % inside the box
            end
        end
end

% figure(1)
% plot(cMap)
% 
% figure(2)
% surf(cMap)

% Using Info from Finite Diff LaPlace Lectures Slides 37,39
% G Matrix
for i = 1:nx
    for j = 1:ny
        n = j + (i - 1) * ny;

        if i == 1
            G(n, :) = 0;
            G(n, n) = 1;
            V(n) = stepped_voltage;
        elseif i == nx
            G(n, :) = 0;
            G(n, n) = 1;
        elseif j == 1
            nxm = j + (i - 2) * ny;
            nxp = j + (i) * ny;
            nyp = j + 1 + (i - 1) * ny;

            rxm = (cMap(i, j) + cMap(i - 1, j)) / 2.0;
            rxp = (cMap(i, j) + cMap(i + 1, j)) / 2.0;
            ryp = (cMap(i, j) + cMap(i, j + 1)) / 2.0;

            G(n, n) = -(rxm+rxp+ryp);
            G(n, nxm) = rxm;
            G(n, nxp) = rxp;
            G(n, nyp) = ryp;

        elseif j ==  ny
            nxm = j + (i - 2) * ny;
            nxp = j + (i) * ny;
            nym = j - 1 + (i - 1) * ny;

            rxm = (cMap(i, j) + cMap(i - 1, j)) / 2.0;
            rxp = (cMap(i, j) + cMap(i + 1, j)) / 2.0;
            rym = (cMap(i, j) + cMap(i, j - 1)) / 2.0;

            G(n, n) = -(rxm + rxp + rym);
            G(n, nxm) = rxm;
            G(n, nxp) = rxp;
            G(n, nym) = rym;
        else
            nxm = j + (i-2)*ny;
            nxp = j + (i)*ny;
            nym = j-1 + (i-1)*ny;
            nyp = j+1 + (i-1)*ny;

            rxm = (cMap(i,j) + cMap(i-1,j))/2.0;
            rxp = (cMap(i,j) + cMap(i+1,j))/2.0;
            rym = (cMap(i,j) + cMap(i,j-1))/2.0;
            ryp = (cMap(i,j) + cMap(i,j+1))/2.0;

            G(n,n) = -(rxm+rxp+rym+ryp);
            G(n,nxm) = rxm;
            G(n,nxp) = rxp;
            G(n,nym) = rym;
            G(n,nyp) = ryp;
        end

    end
end

Voltage = G\V;
Vmap = zeros(nx,ny);

% zz = reshape(Voltage,[10,20]); % doesnt work: try loop to reshape vmap
for x = 1:nx
    for y = 1:ny
        n = y + (x-1)*ny;
        Vmap(x,y) = Voltage(n);
    end
end

% figure(3)
% surf(Vmap)

% Perform gradient for Ex and Ey
[Ey, Ex] = gradient(Vmap);

Ex = -Ex;
Ey = -Ey;

% figure(4)
% quiver(Ex', Ey');
% axis([0 nx 0 ny]);

% normalize to get current from current density
eFlowx = cMap.*Ex;
eFlowy = cMap.*Ey;


Curr = [eFlowx(:),eFlowy(:)];

% uncomment here to check that total current, avg of end currents is the same
% C0 = sum(eFlowx(1,:));
 Cnx = sum(eFlowx(nx,:));
% Currentt = (C0 + Cnx) * 0.5;

end

